
xrange = 100; n = 50;

my_data = read.table("C://Osama_Uppsala//Spice_plus_logistic//prediction interval//lgcp//max. liklihood//1D//counts_extrap.csv",sep=",")

Y = my_data[,1]

cen = my_data[,2]

lic = cen>70

Y[lic] = NA

E = xrange/n
E = rep(E,n)

I = 1:n

formula = Y~1+f(I,model="rw2d",nrow=1,ncol=n)

result = inla(formula,data = data.frame(Y,cen),family = "poisson",E=E, control.predictor = list(compute=TRUE),control.compute=list(dic=TRUE,cpo=TRUE))

f.intercept = result$summary.fixed$mean

f.spat = result$summary.random$I$mean

f.sd = result$summary.random$I$sd

write.table(data.frame(f.spat,f.sd,f.intercept),"C:/Osama_Uppsala/Spice_plus_logistic/prediction interval/lgcp/max. liklihood/1D/extrap_results_from_r.csv",sep = ",",col.name=FALSE,row.name=FALSE)

