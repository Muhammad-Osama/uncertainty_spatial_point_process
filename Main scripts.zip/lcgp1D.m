data = csvread('C:\Osama_Uppsala\Spice_plus_logistic\prediction interval\lgcp\max. liklihood\1D\extrap_results_from_r.csv');

xsamples = csvread('C:\Osama_Uppsala\Spice_plus_logistic\prediction interval\lgcp\max. liklihood\1D\events_extrap.csv');

lat_mu = data(:,1); 

lat_sd = data(:,2);

intercept = data(:,3);

Z_mu = intercept + lat_mu;

%approximate mean and standard deviation of lambda
lambda_mu = exp(Z_mu);
lambda_sd = exp(Z_mu).*lat_sd;

%interval using Chevyshev, with more that 80% coverage
lambda_upp = lambda_mu + 1.118.*lambda_sd;
lambda_low = lambda_mu - 1.118.*lambda_sd;

%grid for plotting
xgrid = linspace(0,100,50)'; 

%%
%intensity
alpha = 10; beta = 50;
lambda = @(x) alpha.*exp(-x./beta);

%%
%plot
figure;
plot(xgrid,lambda(xgrid),'r','LineWidth',2); grid on; hold on;

scatter(xsamples,zeros(length(xsamples),1),'kx');

%plot(xgrid,lambda_mu,'b--','LineWidth',2);

fill([xgrid;flipud(xgrid)],[lambda_low;flipud(lambda_upp)],[0 0.5 0],'FaceAlpha',0.5);

% plot([30 30],[0 15],'m-')
% 
% plot([80 80],[0 15],'m-')

plot([70 70],[0 60],'m-')

xlabel('$x$','interpreter','Latex'); ylim([0 15])

hold on;

legend({'$\lambda(x)$','$Point~data$','$\Lambda_{\alpha}(x)$','$Missing$'},'interpreter','Latex')
