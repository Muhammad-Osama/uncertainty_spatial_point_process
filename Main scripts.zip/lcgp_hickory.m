data = csvread('C:\Osama_Uppsala\Spice_plus_logistic\prediction interval\lgcp\max. liklihood\hickory_results_from_r.csv');

event = csvread('C:\Osama_Uppsala\Spice_plus_logistic\Poisson regression\hickories.csv',1,0);

K = 279.47/100;

event = event.*K;
%%
lic = (event(:,1)>60 & event(:,2)<30)|(event(:,1)>20 & event(:,1)<50 & event(:,2)>60 & event(:,2)<90);
%%
lat_mu = data(:,1); 

lat_sd = data(:,2);

intercept = data(:,3);

Z_mu = intercept + lat_mu;

%approximate mean and standard deviation of lambda
lambda_mu = exp(Z_mu);
lambda_sd = exp(Z_mu).*lat_sd;

%interval using Chevyshev, with more that 80% coverage
lambda_upp = lambda_mu + 1.118.*lambda_sd;
lambda_low = lambda_mu - 1.118.*lambda_sd;

%grid for plotting
xgrid = linspace(0,279.47,30)'; ygrid = linspace(0,279.47,30)';
[X,Y] = meshgrid(xgrid,ygrid);

%%
%plot
figure;
contourf(X,flipud(Y),reshape(lambda_upp,30,30)); 
colorbar; xlabel('$x_1$','interpreter','Latex');
ylabel('$x_2$','interpreter','Latex');
hold on;
plot([20 50 50 20 20],[60 60 90 90 60],'m--','LineWidth',1.5);
plot([60 100 100 60 60],[0 0 30 30 0],'m--','LineWidth',1.5);
legend({'$Upper~limit~with~80\%~coverage$','$Missing$'},'interpreter','Latex')

figure;
contourf(X,flipud(Y),reshape(lambda_low,30,30));
colorbar; xlabel('$x_1$','interpreter','Latex');
ylabel('$x_2$','interpreter','Latex');
hold on;
plot([20 50 50 20 20],[60 60 90 90 60],'m--','LineWidth',1.5);
plot([60 100 100 60 60],[0 0 30 30 0],'m--','LineWidth',1.5);
legend({'$Lower~limit~with~80\%~coverage$','$Missing$'},'interpreter','Latex')

figure;
contourf(X,flipud(Y),reshape((lambda_upp-lambda_low)./7.81,30,30));
colorbar; xlabel('$x_1~m$','interpreter','Latex');
ylabel('$x_2~m$','interpreter','Latex');
hold on;
plot(K.*[20 50 50 20 20],K.*[60 60 90 90 60],'m--','LineWidth',1.5);
plot(K.*[60 100 100 60 60],K.*[0 0 30 30 0],'m--','LineWidth',1.5);
legend({'$|\Lambda_{\alpha}(x)|$','$Missing$'},'interpreter','Latex')

figure;
contourf(X,flipud(Y),reshape(lambda_mu,30,30));
colorbar; xlabel('$x_1$','interpreter','Latex');
ylabel('$x_2$','interpreter','Latex');
hold on;
scatter(event(~lic,1),event(~lic,2),'kx');
plot([20 50 50 20 20],[60 60 90 90 60],'m--','LineWidth',1.5);
plot([60 100 100 60 60],[0 0 30 30 0],'m--','LineWidth',1.5);
legend({'$Mean~\lambda(x)$','$Point~data$','$Missing$'},'interpreter','Latex')
