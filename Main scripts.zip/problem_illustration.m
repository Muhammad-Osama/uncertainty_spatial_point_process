%% Description
%Illustrates the problem
%------
%This script finds the conformal prediction intervals using our model+
%regularized learning method for the interpolation and extrapolation 
%scenarios
%-------
%1D space [0,200] divided into Nbins regions 'X_r'. Given 'r', counts 'y' in each bin 
%generated as a draw from a Poisson distribution with mean 
%E[y|r]= \int_{X_r} \lambda(x) where \lambda(x) is the underlying intensity
%function here proportional to a Gaussian which peaks so that we have
%maximum counts at 50
%-------
%plots the true intensity and the (1-alpha)\% conformal prediction interval


%% set the seed
stream = RandStream('mt19937ar','Seed',0);
RandStream.setGlobalStream(stream);
savedState=stream.State;
%%
%range
mn = 0; mx = 200;

Nbins = 50;
%bin centers
cen = linspace(mn,mx,Nbins)'; 
%width of bin
A = cen(2)-cen(1);

%avgCnt
mxCnt = 25; 
avg_cnts = mxCnt.*(cos(2*pi*1/mx.*cen)+1.5);

%intensity
lam = avg_cnts./A;

%missing data
lic = (cen>30 & cen<80) | (cen>160);
%observed data
r = cen(~lic);
%nos. of points
N = size(cen,1);

%define basis
support = 150;
[Phi, phiB] = define_basis(r,cen,support);

%index to update
ind = index2update(Phi);

%paramters for fitting
%rate of decrease of regularization
gamma = 0.4;  
%nos. of cycles of coordinate descent
L = 20; 
%upper bound on max possible counts in a bin
Y = 100;

%Regularized or unregularized 
md = 'reg';

%parameters for prediction interval
alpha = 0.2; Yu = 3*Y; Yl = 0;

%%
    %generate data
    cnts = poissrnd(avg_cnts);
    %observed data
    y = cnts(~lic);
    %fit 
    D = size(cen,1);
    theta_tilda = randn(D,1);
    if strcmp(md, 'reg')==1
        theta = fit_regul_poisson(y, Phi, gamma, Y, L, theta_tilda , ind);
    elseif strcmp(md ,'ureg')==1
        theta = fit_unreg_poisson(y,Phi,gamma,Y,theta_tilda);
    elseif stcmp(md,'ls')==1
        theta = (Phi'*Phi)\(Phi'*y);
    end
    %eval intensity
    [~,lambda_hat,~,~] = eval_output_qaunt_1D(cen,A,phiB,theta,10,0.1);
    %prediction interval
    [lambda_upp, lambda_low, ~ , ~] = eval_conformal_pred_interval(alpha,Yu,Yl,y,cen,lambda_hat,Phi,phiB,A,gamma,Y,L,theta_tilda,md);

%%
figure;
p1 = plot(cen,lam,'r-','LineWidth',2); hold on; grid on;
p2 = plot(cen,lambda_hat,'b--','LineWidth',2);
p3 = fill([cen;flipud(cen)],[lambda_low;flipud(lambda_upp)],[0.5 0.5 0.5],'FaceAlpha',0.5); 
p4 = plot([30 30],[0 60],'m-');
p5 = plot([80 80],[0 60],'m-');
p6 = plot([160 160],[0 60],'k-');
legend([p1,p2,p3,p4,p6],{'$\lambda(x)$','$\widehat{\lambda}(x)$','$\Lambda_{\alpha}(x)$','$Missing~b/w$','$Missing~right$'},'interpreter','Latex')
%%

