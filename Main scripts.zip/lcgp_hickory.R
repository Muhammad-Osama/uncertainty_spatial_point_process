events = read.table("C://Osama_Uppsala//Spice_plus_logistic//Poisson regression//hickories.csv",sep=",")

grd = read.table("C://Osama_Uppsala//Spice_plus_logistic//prediction interval//lgcp//max. liklihood//hickory_grd.csv",sep=",")
  
x = events[,1]*100

y = events[,2]*100

lic = (grd[,1]>60 & grd[,2]<30)|(grd[,1]>20 & grd[,2]<50 & grd[,2]>60 & grd[,2]<90)

x.area = 100;

x.win = owin(c(0,x.area),c(0,x.area))

data.pp = ppp(x,y,window=x.win)

plot(data.pp)

nrow = 30

ncol = nrow

x.grid = quadrats(x.win,nrow,ncol)

count.grid = quadratcount(data.pp,tess=x.grid)

plot(count.grid)

Y = as.vector(count.grid)

Y[lic] = NA

n = ncol*nrow

cell.area = x.area^2/n

E = rep(cell.area,n)

I = 1:n

formula = Y~1+f(I,model="rw2d",nrow=nrow,ncol=ncol)

result = inla(formula,data = data.frame(Y,I), family = "poisson", E=E, control.predictor = list(compute=TRUE),control.compute=list(dic=TRUE,cpo=TRUE))

f.intercept = result$summary.fixed$mean

f.spat = result$summary.random$I$mean

f.sd = result$summary.random$I$sd

INLA:::inla.display.matrix(matrix(f.spat,nrow,ncol))

write.table(data.frame(f.spat,f.sd,f.intercept),"C:/Osama_Uppsala/Spice_plus_logistic/prediction interval/lgcp/max. liklihood/hickory_results_from_r.csv",sep = ",",col.name=FALSE,row.name=FALSE)
